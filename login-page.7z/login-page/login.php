<?php
error_reporting(E_ALL);
function Login()
{
  #include '/home/pieter/Documents/Project 2.2/kyoto-website/login-page/connect.php';
  echo "hoi2";
  if(empty($_POST)['email']))
  {
    echo "hoi1";
    return("Fill in an e-mail address!");
  }
  if(empty($_POST['password']))
  {
    return("Fill in an Password");
  }
  $email = trim($_POST)['email']);
  $password = trim($_POST)['password']);
   echo "hoi";
   connect($email,$password);
   echo "hoi";
}
?>
